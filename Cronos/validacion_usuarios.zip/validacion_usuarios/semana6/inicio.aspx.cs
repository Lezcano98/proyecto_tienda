﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace semana6
{
    public partial class inicio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btningresar_Click(object sender, EventArgs e)
        {
            string s = System.Configuration.ConfigurationManager.ConnectionStrings["UTCConnectionString"].ConnectionString;
            SqlConnection conexion = new SqlConnection(s);
            // seimpre hay que cerrar las conexiones 
            conexion.Open();
         SqlCommand comando = new SqlCommand("select nombre,clave from usuarios where nombre = '"+txtusuario.Text+"' and clave ='"+txtclave.Text+"'",conexion);
            // lo que lea lo va a pasar a la variable registro
            SqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                Global.Setusuario(txtusuario.Text);
                Response.Redirect("contactos.aspx");

            }
            else
            {
                this.lblmensaje.Text = "el usuario no se encuantra registrado";
            }
            // cerrando la conexion
            conexion.Close();
           
        }

        protected void btnborrar_Click(object sender, EventArgs e)
        {
            string s = System.Configuration.ConfigurationManager.ConnectionStrings["UTCConnectionString"].ConnectionString;
            SqlConnection conexion = new SqlConnection(s);
            // seimpre hay que cerrar las conexiones 
            conexion.Open();
            SqlCommand comando = new SqlCommand("delete usuarios where nombre = '" + txtusuario.Text + "'", conexion);
            int cantidad = comando.ExecuteNonQuery();
            if (cantidad == 1)
            {

                this.lblmensaje.Text = "usuario borrado";
            }
          else
            {
                this.lblmensaje.Text = "el usuario no existe";
            }
            conexion.Close();
        }

        protected void btnagregar_Click(object sender, EventArgs e)
        {
            string s = System.Configuration.ConfigurationManager.ConnectionStrings["UTCConnectionString"].ConnectionString;
            SqlConnection conexion = new SqlConnection(s);
            // seimpre hay que cerrar las conexiones 
            conexion.Open();
            SqlCommand comando = new SqlCommand("insert into usuarios (nombre,clave) values('" + txtusuario.Text + "','"+txtclave.Text+"')",conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            Response.Redirect("usuarios.aspx");

        }

        protected void btnactualizar_Click(object sender, EventArgs e)
        {
            string s = System.Configuration.ConfigurationManager.ConnectionStrings["UTCConnectionString"].ConnectionString;
            SqlConnection conexion = new SqlConnection(s);
            // seimpre hay que cerrar las conexiones 
            conexion.Open();
            SqlCommand comando = new SqlCommand("update usuarios set clave ='"+txtclave.Text+"',correo='"+txtcorreo.Text+"' where nombre = '" + txtusuario.Text + "'", conexion);
            int cantidad = comando.ExecuteNonQuery();
            if (cantidad == 1)
            {

                this.lblmensaje.Text = "usuario actualizado";
            }
            else
            {
                this.lblmensaje.Text = "el usuario no existe";
            }
            conexion.Close();

        }

        protected void btnconsultar_Click(object sender, EventArgs e)
        {
            string s = System.Configuration.ConfigurationManager.ConnectionStrings["UTCConnectionString"].ConnectionString;
            SqlConnection conexion = new SqlConnection(s);
            // seimpre hay que cerrar las conexiones 
            conexion.Open();
            SqlCommand comando = new SqlCommand("select nombre,clave,correo from usuarios where nombre = '" + txtusuario.Text + "'", conexion);
            // lo que lea lo va a pasar a la variable registro
            SqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                this.lblmensaje.Text = "";
                this.txtclave.Text = registro["clave"].ToString();
                this.txtcorreo.Text = registro["correo"].ToString();

            }
            else
            {
                this.lblmensaje.Text = "el usuario no se encuantre registrado";
            }
            // cerrando la conexion
            conexion.Close();
        }
    }
}