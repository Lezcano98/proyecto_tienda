﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace semana6
{
    public class Global
    {
       public static string usuario;
       public static string  clave;

        public static string Usuario
        {
            get
            {
                return usuario;
            }

          private  set 
            {
                usuario = value;
            }
        }

        public static string Clave
        {
                   get
            {
                return clave;
            }

          private  set 
            {
                clave = value;
            }
        }
        public static void Setusuario(string nombreusuario)
        {
            usuario = nombreusuario;

        }

        public static void SetClave(string Contrasena)
        {
            clave = Contrasena;

        }


    }
}