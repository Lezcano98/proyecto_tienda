create database UTC

create table usuarios(
codigo int primary key identity(1,1),
nombre varchar(50) unique,
clave varchar (20) not null,
correo varchar(30)null
)
insert into usuarios values('lisbeth',123,'listc@gmail.com')
insert into usuarios values('leonardo',124,'leoselacome@gmail.com')
select * from usuarios